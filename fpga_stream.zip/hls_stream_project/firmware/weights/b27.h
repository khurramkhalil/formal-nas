//Numpy array shape [10]
//Min -0.239602118731
//Max 0.242527216673
//Number of zeros 0

#ifndef B27_H_
#define B27_H_

#ifndef __SYNTHESIS__
classifier_bias_t b27[10];
#else
classifier_bias_t b27[10] = {-0.0002909005, -0.1628011167, -0.2396021187, -0.1931216419, 0.2425272167, 0.1472290754, 0.1679668427, -0.1325934827, 0.1620327830, 0.1341525912};

#endif

#endif
