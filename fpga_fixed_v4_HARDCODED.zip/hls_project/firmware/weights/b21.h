//Numpy array shape [10]
//Min -0.200563520193
//Max 0.222471505404
//Number of zeros 0

#ifndef B21_H_
#define B21_H_

#ifndef __SYNTHESIS__
classifier_bias_t b21[10];
#else
classifier_bias_t b21[10] = {-0.2005635202, 0.0787072480, 0.0042532980, 0.0465584695, -0.0301667154, 0.2224715054, 0.1015703678, -0.1066918671, 0.1765432358, 0.2200233936};

#endif

#endif
