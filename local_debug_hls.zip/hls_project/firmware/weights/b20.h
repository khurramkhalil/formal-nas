//Numpy array shape [10]
//Min -0.234619259834
//Max 0.191281020641
//Number of zeros 0

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
classifier_bias_t b20[10];
#else
classifier_bias_t b20[10] = {0.1318565011, -0.2130905092, 0.1906916797, -0.0791998804, 0.0795387626, 0.1633937061, 0.1912810206, -0.2346192598, -0.2027129531, -0.1784464419};

#endif

#endif
