//Numpy array shape [10]
//Min -0.205354273319
//Max 0.209364712238
//Number of zeros 0

#ifndef B21_H_
#define B21_H_

#ifndef __SYNTHESIS__
classifier_bias_t b21[10];
#else
classifier_bias_t b21[10] = {-0.2053542733, 0.0509846509, 0.2093647122, 0.0649085939, 0.0180749893, 0.1186999679, 0.0033525229, -0.1741812229, -0.0522074103, 0.2093611956};

#endif

#endif
