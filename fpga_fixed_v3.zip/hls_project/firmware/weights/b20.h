//Numpy array shape [10]
//Min -0.197879642248
//Max 0.247963726521
//Number of zeros 0

#ifndef B20_H_
#define B20_H_

#ifndef __SYNTHESIS__
classifier_bias_t b20[10];
#else
classifier_bias_t b20[10] = {0.0634436011, 0.1588062346, -0.0171768665, 0.0932742953, 0.2269291878, 0.2479637265, -0.1590625346, 0.0553373694, -0.1978796422, 0.0082943439};

#endif

#endif
